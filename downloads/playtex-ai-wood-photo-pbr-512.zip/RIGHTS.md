This archive contains only the first-party Wood Photo PBR sample, licensed CC BY 4.0. See README.md for attribution and limitations.
