# PLAYTEX AI — Apricot Orbit

Open assets/skyboxes/apricot-orbit/ for the 2048 × 1024 PNG panorama, six 512px faces, and skybox.json metadata. This is an original stylized LDR background, not a calibrated HDR light probe. Standard-dx cubemap orientation; Three.js face order px, nx, py, ny, pz, nz. Roblox pole rotations are not baked in.

CC BY 4.0 with attribution. [Skybox guide](https://github.com/playtex-ai/creator-playground/blob/main/guides/skybox-generator.md)
