# PLAYTEX AI — peach-ceramic

Open assets/materials/peach-ceramic/ for the original 512px source, seven PNG maps, and material.json settings. Normal is OpenGL (+Y); roughness is not smoothness. Color maps: albedo and emission. Other maps are linear data. Emission is disabled.

Use and adapt commercially with attribution under the included CC BY 4.0 LICENSE. These stylized examples are not measured scans or native-engine-certified packages.

[Map setup and engine guide](https://github.com/playtex-ai/creator-playground/blob/main/guides/engine-handoff.md) · [PLAYTEX AI](https://www.playtex.ai/)
