# PLAYTEX AI Creator Playground — Starter Pack 1.0.0

Three original 512px material sources, 21 PBR maps, one 2048 × 1024 LDR panorama, and six 512px cube faces. Material settings, source provenance, and conventions are alongside each sample. These are stylized learning assets, not measured scans or native-engine-certified projects.

Free for personal and commercial projects under CC BY 4.0 with attribution. Read LICENSE and RIGHTS.md. SHA256SUMS.txt verifies this archive's contents. PROVENANCE.json also describes repository-only preview images, which are not included in this ZIP.

[All guides](https://github.com/playtex-ai/creator-playground/blob/main/guides/README.md) · [Engine setup](https://github.com/playtex-ai/creator-playground/blob/main/guides/engine-handoff.md) · [PLAYTEX AI](https://www.playtex.ai/)
